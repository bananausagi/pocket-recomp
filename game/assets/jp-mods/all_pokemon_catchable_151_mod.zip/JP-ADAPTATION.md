# Japanese Red adaptation

Upstream: https://github.com/wowabox/All_Pokemon_Catchable_151_Mod

Author: Wowabox (Darklinkduck).
License: MIT; original copyright and license preserved in `License`.

Source: official release tag `v0.3.3`, asset `All_Pokemon_Catchable_151_Mod_V0.3.3.zip`.
Asset URL: https://github.com/wowabox/All_Pokemon_Catchable_151_Mod/releases/download/v0.3.3/All_Pokemon_Catchable_151_Mod_V0.3.3.zip
Asset SHA-256: `4239ab5b3e6867d86fbd257eec716b817eb67c2c39ae9286b79a7acd1402223d`.

The source manifest calls this version `0.3.3-beta - Yellow Support Hotfix`.
This string is not a semantic version. The Japanese distribution labels the
adaptation `0.3.3-beta.1+jp.1`; this is our normalized/adapted version, not a claim
that the author published a tag named `v0.3.3-beta.1`.
The original manifest is kept as `manifest.upstream.json`.

Changes:

- Manifest name/description translated into Japanese.
- Target limited to `red_jp` and engine `>=0.2.66 <0.3.0`.
- Version normalized as described above. No automatic upstream replacement is configured.
- `main.lua` is byte-for-byte unchanged from the author's release ZIP.
- Only the six public source/document files and these adaptation records are
  packaged; development repository history contained in the author ZIP is excluded.

The mod changes encounter tables, trade-evolution rules, Moon Stone pricing and
shop inventories. It does not change catch probabilities or claim that already
lost unique encounters are restored. Its gameplay balance is the author's.

The JP manifest contains every referenced species, encounter map and shop clerk
symbol. `tests/catchable151_jp_test.lua` uses the actual loader and handwritten,
ROM-free data to check registration, preserved encounter rates/water tables
(except the author's explicit Cerulean Cave rates of 10/15/25),
evolution targets, and adding Moon Stone without removing existing shop items.
This is not an end-to-end playthrough or proof of completion with every old save.
