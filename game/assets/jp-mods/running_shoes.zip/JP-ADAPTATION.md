# Japanese Red Android adaptation

Upstream: https://github.com/MadeinTaly/gen1recomp-running-shoes

Pinned commit: 6f911f1c8e6f07584aa298c7fb97626cb486e532

The manifest limits this copy to red_jp on Gen1Recomp JP 0.1.0-jp.3.
The upstream update field is omitted to preserve these compatibility changes.
Original authors and license are preserved; see LICENSE.

## MOD 1.10.0+jp.4 / jp19

The free-camera movement adapter now recognizes VOXEL_ASCENDANT and
DRAMALESS_SHAPE as well as DRAMATIC_SHAPE. B running and the saved BOOST BIKE
choice apply to their actual movement. BOOST BIKE defaults on when no choice
has been saved: at the default x2 run speed, riding moves at twice walking
speed and holding B doubles it again (four times walking speed). An explicitly
saved false is preserved. Base speed without B, the four-frame speed floor
and scripted escort timing are unchanged.

JP.3 update: short Japanese name/description and exact engine version pin.

## 0.2.66-jp.4

本体の互換バージョンを本家0.2.66へ更新。manifestの対象を `>=0.2.66 <0.3.0` とし、既存の日本語表示・Android向け調整を維持。MODの改変済みコピーと個別設定は自動上書きしません。

## 0.2.89-jp.89

クリスタル（crystal_jp）でも動くように対象へ追加。クリスタル本体のBダッシュとは重ねがけせず、このMODが入っている間はMODの速度（自転車と同じ8フレーム）を使う。3Dの自由移動でも同じ速度。
