# Japanese Red Android adaptation

Upstream: https://github.com/erereck/gen1recomp-bottomless-bag

Pinned commit: 8e91baa7797687c5648d40bc7d2467b20920421a

The manifest limits this copy to red_jp on Gen1Recomp JP 0.1.0-jp.3.
The upstream update field is omitted to preserve these compatibility changes.
Original authors and license are preserved; see LICENSE.

JP.3 update: short Japanese name/description and exact engine version pin.

## 0.2.66-jp.4

本体の互換バージョンを本家0.2.66へ更新。manifestの対象を `>=0.2.66 <0.3.0` とし、既存の日本語表示・Android向け調整を維持。MODの改変済みコピーと個別設定は自動上書きしません。

## 0.2.89-jp.89

クリスタル（crystal_jp）でも動くように対象へ追加。クリスタルでは「どうぐ」ポケットの上限を255しゅるいに広げる（ボール・たいせつなもの・わざマシンのポケットは元のまま）。
