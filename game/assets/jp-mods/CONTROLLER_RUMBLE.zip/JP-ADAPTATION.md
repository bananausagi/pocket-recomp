# Japanese Android adaptation

Upstream: https://github.com/masterwebx/gen1recomp-controller-rumble
Commit: fa7a2157b5bb9b2d68a2b61a0820cd1c17540fae

Pinned for Japanese Red, Gen1Recomp JP 0.1.0-jp.3. Native settings labels are localized by the engine catalog. Original MIT license and author retained.

Starter defaults: low intensity, ambient rumble OFF. This mod targets
supported physical gamepads; phone vibration remains an engine option.

## 0.2.66-jp.4

本体の互換バージョンを本家0.2.66へ更新。manifestの対象を `>=0.2.66 <0.3.0` とし、既存の日本語表示・Android向け調整を維持。MODの改変済みコピーと個別設定は自動上書きしません。

## 0.2.89-jp.89

クリスタル（crystal_jp）に対応。せんとう（こうげき・ひんし・じょうたいいじょう・ボール）、つかまえた・レベルアップ・しんか、トレーナーとの出会い、どうぐ・だんさ・かいりき・そらをとぶ、メニュー音で しんどうする。HPバー連動・画面ゆれ連動・つり・サファリなど赤専用の仕組みはクリスタルには無いので動かない。設定はクリスタルのせっていの最後に6行で並ぶ。
