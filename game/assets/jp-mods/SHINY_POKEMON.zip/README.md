# Shiny Pokemon

Rolls shiny DVs on new wilds, applies Gen 2 Crystal shiny colors, and draws sparkles in battle and on the overworld (including voxel and follower packs when those mods are present).

## Requires

- [gen1recomp](https://github.com/bryanthaboi/gen1recomp) / pokemon-love2d with mod API 2 (`>=0.1.37`)

### Optional (overworld / followers / voxel)

- [Wilds of Kanto](https://github.com/YoDrehDenSwagAuf/overworld-spawn-mod) (`overworld_wild_spawns`)
- [PokéPC Followers](https://github.com/gamecorner-033/PokePCFollowers) (`PokePCFollowers_VoxelMerge`)
- [Followers EX](https://github.com/masterwebx/gen1recomp-followers-ex) (`FOLLOWERS_EX`)
- [Dramatic Shape](https://github.com/DramaticShape/DramaticShapeVoxelMod) (`DRAMATIC_SHAPE`)

## OPTIONS

Pause **OPTIONS → SHINY POKEMON → OPEN**:

- **SHINY POKEMON** — master enable
- **SHINY RATE** — OFF through Always
- **SHINY COLORS** — recolor battle/overworld art
- **SHINY INTRO** — battle intro sparkle/SFX (+ looping overworld sparkles)
- **DEBUG OW** — overworld debug overlay (leave off normally)

## Overworld + Followers EX

Pack and player-as-Pokemon shinies always use **PokePC** walker-sheet bake + sparkles.

Wilds enhanced OW spawns keep native shiny follow-sprite frames (`*-s.png`); our sparkles stay off for those entities.

Stock Yellow talkable companion (`SPRITE_PIKACHU`) always uses Pikachu art (never the OW leader species).

Battle shiny intro/SFX unchanged.

## License

MIT
