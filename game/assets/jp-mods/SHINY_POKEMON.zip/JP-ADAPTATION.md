# Japanese Android adaptation

Upstream: https://github.com/masterwebx/gen1recomp-shiny-pokemon
Commit: 2141b2ed35f4261d7306d8bb4d66a8c50e87125f

Pinned for Japanese Red, Gen1Recomp JP 0.1.0-jp.3. Native settings labels are localized by the engine catalog. Original MIT license and author retained.

JP defaults: 1/8192 shiny rate, diagnostic overworld overlay OFF (including
Reset Defaults). Recolor and sparkle settings retain their upstream behavior.

## 0.2.66-jp.4

本体の互換バージョンを本家0.2.66へ更新。manifestの対象を `>=0.2.66 <0.3.0` とし、既存の日本語表示・Android向け調整を維持。MODの改変済みコピーと個別設定は自動上書きしません。
