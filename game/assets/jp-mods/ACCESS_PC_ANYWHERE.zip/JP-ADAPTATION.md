# Japanese Android adaptation

Upstream: https://github.com/masterwebx/gen1recomp-access-pc-anywhere
Commit: 92fd49f89675b5b1f21f63e9fe51eb43a0820c3c

Pinned for Japanese Red, Gen1Recomp JP 0.1.0-jp.3. Native settings labels are localized by the engine catalog. Original MIT license and author retained.

Fixed optBool so a stored false value is not replaced by the true fallback.
The starter installer seeds overworld_only=false; the command calls the
engine PC, retaining Japanese Red box sizes and save behavior.

## 0.2.66-jp.4

本体の互換バージョンを本家0.2.66へ更新。manifestの対象を `>=0.2.66 <0.3.0` とし、既存の日本語表示・Android向け調整を維持。MODの改変済みコピーと個別設定は自動上書きしません。

## 0.2.89-jp.89

クリスタル（crystal_jp）に対応。クリスタルではスタートメニューに「パソコン」を1行足し、クリスタル本体のパソコン画面を開く。本体の「どこでもパソコン」設定がオンのときは行を重ねない。設定の「ACCESS PC」でそと（みち・まち）だけ／どこでもを切りかえ。
