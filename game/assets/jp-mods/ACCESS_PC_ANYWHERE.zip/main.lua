-- Access PC Anywhere: Start menu -> PC
return function(mod)
  local Strings = require("src.core.Strings")
  local Screens = require("src.ui.Screens")
  -- jp.89: Crystal (generation 2) support.  The Gen 1 field modules are only
  -- required on Red; on Crystal the row opens the engine's own Pokemon
  -- Center PC (Game2:openStartMenuItem("pc")) and the outdoor test reads the
  -- Gen 2 map environment.
  local GEN2 = mod.generation == 2
  local TextBox, Map, FieldDefaults
  if not GEN2 then
    TextBox = require("src.render.TextBox")
    Map = require("src.world.Map")
    FieldDefaults = require("src.world.FieldDefaults")
  end

  mod.options:define({
    {
      key = "overworld_only",
      type = "toggle",
      label = "OVERWORLD ONLY",
      default = true,
      help = "When ON, PC only appears outdoors (not inside buildings).",
    },
  })

  local optCache = {}
  local function optBool(key, default)
    if optCache[key] ~= nil then return optCache[key] end
    local ok, got = pcall(mod.options.get, mod.options, key)
    if ok and got ~= nil then optCache[key] = got and true or false
    else optCache[key] = default end
    return optCache[key]
  end

  local function setOpt(key, value, game)
    optCache[key] = value and true or false
    pcall(function() mod.options:set(key, value and true or false) end)
    if game and game.save then
      game.save.options = game.save.options or {}
      game.save.options.modOptions = game.save.options.modOptions or {}
      game.save.options.modOptions[mod.id] =
        game.save.options.modOptions[mod.id] or {}
      game.save.options.modOptions[mod.id][key] = value and true or false
    end
    if game and game.mods then
      game.mods.modOptions = game.mods.modOptions or {}
      game.mods.modOptions[mod.id] = game.mods.modOptions[mod.id] or {}
      game.mods.modOptions[mod.id][key] = value and true or false
    end
    if game and game.writeOptions then pcall(game.writeOptions, game) end
  end

  mod.events:on("mod.options_changed", function(payload)
    if payload and payload.mod == mod.id then
      optCache[payload.key] = payload.value
    end
  end)

  -- True outdoors only (towns/routes/plateau). Buildings/caves fail this.
  local function isOutdoors(game)
    if GEN2 then
      local w = game and game.world
      local def = w and w.map and w.map.def
      local env = def and def.environment
      return env == "ROUTE" or env == "TOWN"
    end
    local ow = game and game.overworld
    local def = ow and ow.map and ow.map.def
    if not def then return false end
    local tilesets = FieldDefaults.field(game.data, "outsideTilesets")
    return Map.isOutside(def, tilesets)
  end

  -- Crystal: one row only.  When the engine's own どこでも パソコン option
  -- already put a PC row in, the mod adds nothing; otherwise its row opens
  -- that same screen, closed back onto the START menu.
  local function gen2Items(game, items)
    for _, it in ipairs(items) do
      if it.value == "pc" then return items end
    end
    if optBool("overworld_only", true) and not isOutdoors(game) then
      return items
    end
    if not (game and game.openStartMenuItem) then return items end
    table.insert(items, {
      label = Strings("PC"),
      onSelect = function(g)
        local owner = (type(g) == "table" and g.openStartMenuItem) and g or game
        owner:openStartMenuItem("pc")
      end,
    })
    return items
  end

  mod.hooks:wrap("ui.start_menu.items", function(next, game, items)
    items = next(game, items) or items
    if GEN2 then return gen2Items(game, items) end
    if optBool("overworld_only", true) and not isOutdoors(game) then
      return items
    end
    table.insert(items, {
      label = Strings("PC"),
      onSelect = function()
        if optBool("overworld_only", true) and not isOutdoors(game) then
          game.stack:push(TextBox.new(game,
            Strings("PC is not\navailable now.")))
          return
        end
        local ow = game.overworld
        if not ow or not ow.openPC then
          game.stack:push(TextBox.new(game,
            Strings("PC is not\navailable now.")))
          return
        end
        pcall(function() ow:openPC() end)
      end,
    })
    return items
  end)

  -- OPTIONS submenu (QoL-style OPEN row)
  local PC_SCREEN = "AccessPcAnywhereOptions"

  local function makePcScreen(game)
    local OptionRows = require("src.ui.OptionRows")
    local rows = {
      {
        label = "OVERWORLD ONLY",
        value = function()
          return optBool("overworld_only", true) and "ON" or "OFF"
        end,
        step = function(g)
          setOpt("overworld_only", not optBool("overworld_only", true), g)
        end,
      },
    }
    local screen = {
      game = game, rows = rows, index = 1, scroll = 0, isOpaque = true,
    }
    function screen:sgbPalettes(g)
      return require("src.render.PaletteFX").wholeNamed(g.data, "MEWMON")
    end
    function screen:update()
      local input = self.game.input
      if input:wasPressed("up") then
        self.index = (self.index - 2) % #self.rows + 1
      elseif input:wasPressed("down") then
        self.index = self.index % #self.rows + 1
      elseif input:wasPressed("left") or input:wasPressed("right")
          or input:wasPressed("a") then
        local row = self.rows[self.index]
        if row and row.step then row.step(self.game) end
      elseif input:wasPressed("b") then
        self.game.stack:pop()
      end
      self.scroll = OptionRows.clampScroll(
        self.index, self.scroll, #self.rows, nil)
    end
    function screen:draw()
      OptionRows.draw(self.game, self.rows, self.index, self.scroll,
                      "A/◀▶:CHANGE B:DONE")
    end
    return screen
  end

  if not GEN2 then
  mod.content.screens:register(PC_SCREEN, { new = makePcScreen })

  mod.events:once("mods.loaded", function()
    local ManagerState = require("src.mods.ManagerState")
    local routes = rawget(ManagerState, "__modOptionScreenRoutes")
    if not routes then
      routes = {}
      local openOptions = ManagerState.openOptions
      ManagerState.openOptions = function(self, manifest)
        local screenId = manifest and routes[manifest.id]
        if screenId then
          return Screens.push(self.game, screenId)
        end
        return openOptions(self, manifest)
      end
      ManagerState.__modOptionScreenRoutes = routes
    end
    routes[mod.id] = PC_SCREEN
  end)
  end

  mod.hooks:wrap("ui.options.rows", function(next, game, rows)
    local out = next(game, rows)
    if type(out) ~= "table" then return out end
    -- Crystal's OPTION screen steps a Gen 1 style row in place (value/step),
    -- so the setting is a direct toggle there instead of Red's sub-screen.
    local row = GEN2 and {
      id = mod.id .. ":overworld_only",
      label = "ACCESS PC",
      value = function()
        return optBool("overworld_only", true) and "OUTDOORS" or "ANYWHERE"
      end,
      step = function(g)
        setOpt("overworld_only", not optBool("overworld_only", true), g)
      end,
    } or {
      id = mod.id .. ":open",
      label = "ACCESS PC",
      value = function() return "OPEN" end,
      activate = function(g)
        Screens.push(g, PC_SCREEN)
      end,
    }
    if mod.ui and type(mod.ui.insertBefore) == "function" then
      return mod.ui.insertBefore(out, "MODS", row)
    end
    out[#out + 1] = row
    return out
  end)

  mod.exports.version = "1.0.1"
  mod.exports.gen2 = GEN2
  mod.log:info("ACCESS_PC_ANYWHERE 1.0.1")
end
